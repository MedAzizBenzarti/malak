<?PHP
require_once "config.php";


class typeC
{
    function ajoutert($type)
    {
        $sql = "insert into type (id,nom,description) values (:id,:nom,:description)";
        $db = config::getConnexion();
        try {
            $req = $db->prepare($sql);

            $req->bindValue(':id', $type->getid());
            $req->bindValue(':nom', $type->getnom());

            $req->bindValue(':description', $type->getdescription());


            $req->execute();

        } catch (Exception $e) {
            echo 'Erreur: ' . $e->getMessage();
        }
    }

    function affichert()
    {
        $sql = "SELECT * from type";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' .$e->getMessage());
        }
    }


    function supprimert($id)
    {
        $sql = "DELETE FROM type WHERE id= :id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id', $id);
        try {
            $req->execute();
        } catch (Exception $e) {
            die('Erreur: ' .$e->getMessage());
        }
    }
    function recuperert($id){
        $sql="SELECT * from type where id=$id";
        $db = config::getConnexion();
        try{
            $liste=$db->query($sql);
            return $liste;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }




    function modifiert($type, $id)
    {
        try {
            $db = config::getConnexion();
            $query = $db->prepare(
                'UPDATE type SET 
                       id =:id,
						nom = :nom, 
						description = :description,
						
					
					WHERE id = :id'
            );

            $query->execute([
                'id'=>$type->getid(),
                'nom'=>$type->getnom(),
                'description'=>$type->getdescription(),
                // 'idbesoin'=>$association->getidbesoin(),
                'id'=>$id
            ]);
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }

}
?>

