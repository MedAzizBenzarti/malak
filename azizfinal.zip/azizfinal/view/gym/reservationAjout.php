<?php


include "../../entity/reservation.php";
include "../../controller/reservationC.php";
$VC = new reservationC();
if (
    isset($_POST["nbP"]) &&
    isset($_POST["etat"])


) {
    if (
        !empty($_POST["nbP"]) &&
        !empty($_POST["etat"])

    ) {
        $reservation = new reservation(
            $_POST['date'],
            $_POST['dateAjout'],

        );
        $VC->ajouter($evenement);
        header('location:listeEvent.php');
        // var_dump( $voyage);
        //console.log($voyage);
    } else
        // header('location:listeVoyage.php');
        echo "problem !!";
}


?>