<?php

class reservation
{

    private $id;
    private $nbP;
    private $etat;
    private $idevent;
    function __construct($nbP,$etat,$idevent)
    {
        // $this->id=$id;
        $this->nbP=$nbP;
        $this->etat=$etat;
        $this->idevent=$idevent;
    }
    /* function getid()
     {
         return $this->id;

     }
     function setid($id)
     {
         $this->id=$id;

     }*/
    function getnbP()
    {
        return $this->nbP;

    }
    function setnbP($nbP)
    {
        $this->nbP=$nbP;

    }

    function getetat()
    {
        return $this->etat;
    }
    function  setetat($etat)
    {
        $this->etat=$etat;

    }

    function  getidevent()
    {
        return $this->idevent;
    }
    function setidevent($idevent)
    {$this->idevent=$idevent;
    }


}
?>