<?php
class evenement

{
    private $id;
    private $titre;
    private $date;
    private $lieu;
    private $descrip;
    private $dateModif;
    private $dateAjout;
    private $nbPartic;
    private $etat;
    private $idtype;



    function __construct($titre,$date,$lieu,$descrip,$dateModif,$dateAjout,$nbPartic,$etat,$idtype ){
        //$this->id=$id;
        $this->titre=$titre;
        $this->date=$date;
        $this->lieu=$lieu;
        $this->descrip=$descrip;
        $this->dateModif=$dateModif;
        $this->dateAjout=$dateAjout;
        $this->nbPartic=$nbPartic;
        $this->etat=$etat;
        $this->idtype=$idtype;
    }
    /*
    public function getid()
    {
        return $this->id;
    }
    public function setid($id)
    {
        $this->id = $id;

        return $this;
    }*/
    public function gettitre()
    {
        return $this->titre;
    }
    public function settitre($titre)
    {
        $this->titre = $titre;

        return $this;
    }
    public function getdate()
    {
        return $this->date;
    }
    public function setdate($date)
    {
        $this->date = $date;

        return $this;
    }
    public function getlieu()
    {
        return $this->lieu;
    }
    public function setlieu($lieu)
    {
        $this->lieu = $lieu;

        return $this;
    }
    public function getdescrip()
    {
        return $this->descrip;
    }
    public function setdescrip($descrip)
    {
        $this->descrip = $descrip;

        return $this;
    }
    public function getdateModif()
    {
        return $this->dateModif;
    }
    public function setdateModif($dateModif)
    {
        $this->dateModif = $dateModif;

        return $this;
    } public function getdateAjout()
{
    return $this->dateAjout;
}
    function getidtype()
    {
        return $this->idtype;
    }
    public function setdateAjout($dateAjout)
    {
        $this->dateAjout = $dateAjout;

        return $this;
    }
    public function getnbPartic()
    {
        return $this->nbPartic;
    }
    public function setnbPartic($nbPartic)
    {
        $this->nbPartic = $nbPartic;

        return $this;
    }
    public function getetat()
    {
        return $this->etat;
    }
    public function setetat($etat)
    {
        $this->etat = $etat;

        return $this;
    }

    function setidtype($idtype)
    {
        $this->idtype=$idtype;
    }


}
?>